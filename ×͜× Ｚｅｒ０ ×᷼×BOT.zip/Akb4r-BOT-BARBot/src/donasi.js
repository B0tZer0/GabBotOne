const donasi = () => {
	return `	

  Oi👋️
  
          *×͜× Ｚｅｒ０ ×᷼×*
          
┏━━━°❀ ❬ INFO ❭ ❀°━━━┓
┃
┏❉ *#info*
┣❉ *#Donasi* 
┗❉ *#creator* 
┃
┣━━━°❀ ❬  ❭ ❀°━━━⊱
┃
┣➥ *Zer0:* +1 (579) 509-0280
┣➥ *GitHub:*
┃   https://github.com/B0tZer0/GabBotThree
┣━━━━━━━━━━━━━━━━━━━━
┃ 🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
