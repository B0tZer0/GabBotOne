const help = (prefix) => {
	return `ZER0-BOT
	
	                
┏━━━°❀ ❬ ×͜× Ｚｅｒ０ ×᷼× ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}creator*
┃
┣━━━°❀ ❬ ×͜× Ｚｅｒ０ ×᷼× ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker* [foto]
┣➥ *${prefix}stickergif* [foto]
┣➥ *${prefix}sticker nobg 
┣➥ *${prefix}thunder* [teks]
┣➥ *${prefix}tsticker* [teks/url]
┃
┣━━━━°❀ ❬ ×͜× Ｚｅｒ０ ×᷼× ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts* [teks]
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┣➥ *${prefix}toimg*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}wait* [foto]
┣➥ *${prefix}simi
┣➥ *${prefix}simih*
┣➥ *${prefix}wait*
┃
┣━━━━°❀ ❬ ×͜× Ｚｅｒ０ ×᷼× ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}setname*
┣➥ *${prefix}setdesc*
┣➥ *${prefix}getpp*
┣➥ *${prefix}tagall*
┣➥ *${prefix}linkgroup
┣➥ *${prefix}gprofile*
┣➥ *${prefix}setprefix
┣➥ *${prefix}welcome*
┣➥ *${prefix}left*
┃
┣━━━━°❀ ❬ ×͜× Ｚｅｒ０ ×᷼× ❭ ❀°━━━━━⊱
┃
┣➥ *salam*
┣➥ *tariksis*
┣➥ *baka*
┣➥ *desah*
┣➥ *goblok*
┣➥ *roti*
┣➥ *welot*
┣➥ *abangjago*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃obrigado To : ×͜× Ｚｅｒ０ ×᷼× ID
┃Segue Ig : tem não k
┃Proprietário     : Zer0zin
┃Segue Ig : tem não k
┃
┃E graças a🔥
┃×͜× Ｚｅｒ０ ×᷼×
┣━━━━━━━━━━━━━━━━━━━━
┃ 🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿🗿
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.help = help

